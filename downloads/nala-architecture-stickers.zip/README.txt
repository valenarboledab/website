Nala stickers by Studio Valentina (studio-valentina.com)
Free for personal use: WhatsApp, Telegram, iMessage, Instagram stories, Procreate, GoodNotes, Notion.
Transparent PNG, 900px. Not for resale.
